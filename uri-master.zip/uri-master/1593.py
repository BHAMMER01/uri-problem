for g in range(int(input())): print(bin(int(input())).count('1'))
