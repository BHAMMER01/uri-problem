i = 1
for j in range(int(input())):
    print(i, i+1, i+2, 'PUM')
    i += 4
