input()
v = [int(x) for x in input().split()]
print('Menor valor:', min(v))
print('Posicao:', v.index(min(v)))
