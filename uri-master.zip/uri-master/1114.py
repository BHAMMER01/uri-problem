while int(input()) != 2002: print('Senha Invalida')
print('Acesso Permitido')
