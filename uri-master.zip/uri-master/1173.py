n = int(input())
for i in range(10):
    print('N[{}] ='.format(i), n)
    n *= 2
