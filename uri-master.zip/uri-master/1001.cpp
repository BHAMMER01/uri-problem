#include <iostream>

using namespace std;

int main(void) {
    int a, b;
    cin >> a >> b;
    cout << "X = " << a + b << endl;
    return 0;
}
