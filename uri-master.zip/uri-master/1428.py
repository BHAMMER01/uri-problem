for g in range(int(input())):
   a, b = [int(x) for x in input().split()]
   print((a//3) * (b//3))
