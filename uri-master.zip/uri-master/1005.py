a = float(input())
b = float(input())
m = (a * 3.5 + b * 7.5) / 11
print('MEDIA = {:.5f}'.format(m))
