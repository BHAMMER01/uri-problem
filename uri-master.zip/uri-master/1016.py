print('{} minutos'.format(int(input()) * 2))
