print('VOLUME = {:.3f}'.format(float(input())**3 * 3.14159 * 4/3 ))
