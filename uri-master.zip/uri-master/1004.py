print('PROD =', int(input()) * int(input()))
