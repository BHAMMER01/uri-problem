v = [int(x) for x in str(input()).split()]
print(str(max(v)), 'eh o maior')
