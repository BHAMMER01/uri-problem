print('X =', int(input()) + int(input()))
