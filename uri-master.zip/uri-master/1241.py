for g in range(int(input())):
    a, b = input().split()
    if a.endswith(b): print('encaixa')
    else: print('nao encaixa')
