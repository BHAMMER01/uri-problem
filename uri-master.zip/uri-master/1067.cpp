#include <iostream>

using namespace std;

int main(void)
{
    int n, i;
    cin >> n;
    for (i = 1; i <= n; i+=2) cout << i << endl;
    return 0;
}

