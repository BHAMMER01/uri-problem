n = int(input())
if n % 2 == 0: n += 1
for i in range(6):
    print(n)
    n += 2
