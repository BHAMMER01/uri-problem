input()
b = float(input())
v = float(input())
print('TOTAL = R$ {:.2f}'.format(b + v * 0.15))
