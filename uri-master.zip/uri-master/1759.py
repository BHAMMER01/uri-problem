for g in range(int(input())-1): print('Ho', end=' ')
print('Ho!')
