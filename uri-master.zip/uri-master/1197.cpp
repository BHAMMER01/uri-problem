#include <iostream>

using namespace std;

int main(void) {
    int t, v;
    while (cin >> t >> v)
        cout << t * v * 2 << endl;
    return 0;
}

