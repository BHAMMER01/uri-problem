#include <iostream>

using namespace std;

int main(void) {
    int a, b, c, d, dif;
    cin >> a >> b >> c >> d;
    dif = (a * b - c * d);
    cout << "DIFERENCA = " << dif << endl;
    return 0;
}


