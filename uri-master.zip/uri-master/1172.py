for i in range(10):
    n = int(input())
    print('X[{}] ='.format(i), end=' ')
    print(1 if n <= 0 else n)
