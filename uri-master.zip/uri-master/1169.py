for g in range(int(input())):
    n = int(input())
    p = int((2 ** n) / 12000)
    print(p, 'kg')
