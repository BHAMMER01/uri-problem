#include <iostream>

using namespace std;

int main(void) {
   int q, i;

   cin >> q;

   for (i = 0; i < q - 1; ++i)
      cout << "Ho ";
   cout << "Ho!" << endl;
   return 0;
}
