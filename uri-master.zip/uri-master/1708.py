from math import ceil
e = str(input()).split()
a = int(e[0])
b = int(e[1])
print(ceil(b / (b - a)))
