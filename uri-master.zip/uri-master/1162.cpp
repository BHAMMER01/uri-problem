#include <iostream>

using namespace std;

int main(void) {
   short g, q, n, v[50], i, ind, t, x;

   cin >> q;
   for (g = 0; g < q; ++g) {
      cin >> n;
      for (i = 0; i < n; ++i)
         cin >> v[i];
      i = 1;
      t = 0;
      while (i <= n) {
         while (v[i-1] != i) {
            ind =
         }
      }
   }

   return 0;
}

