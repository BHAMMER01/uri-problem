r = float(input())
a = r * r * 3.14159
print('A={:.4f}'.format(a))
