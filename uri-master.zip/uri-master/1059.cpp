#include <iostream>
#include <iomanip>

using namespace std;

int main(void)
{
    int i;
    for (i = 2; i <= 100; i += 2) cout << i << endl;
    return 0;
}
