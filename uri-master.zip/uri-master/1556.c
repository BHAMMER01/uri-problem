#include <stdio.h>

void esc(char *c) {

}

int main(void) {
   esc("abc");
   return 0;
}

