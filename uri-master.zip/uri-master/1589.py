for g in range(int(input())):
     print(sum([int(x) for x in input().split()]))
