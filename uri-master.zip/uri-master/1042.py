v = [int(x) for x in input().split()]
o = sorted(v)
for i in o: print(i)
print()
for i in v: print(i)
