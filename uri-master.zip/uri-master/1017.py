print('{:.3f}'.format((int(input()) * int(input())) / 12))
