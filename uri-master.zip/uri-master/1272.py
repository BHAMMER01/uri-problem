n = int(input())
for i in range(n):
    e = str(input()).split()
    for j in e:
        print(j[0], end='')
    print()
