from math import ceil
for g in range(int(input())):
    print(ceil(int(input()) / 2))
