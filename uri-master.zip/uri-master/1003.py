print('SOMA =', int(input()) + int(input()))
