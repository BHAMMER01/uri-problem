#include <iostream>
#include <iomanip>

using namespace std;

int main(void)
{
    int a;
    cin >> a;
    cout << a*2 << " minutos" << endl;
    return 0;
}

