for i in range(100):
    n = float(input())
    if n <= 10: print('A[{}] = {:.1f}'.format(i, n))
