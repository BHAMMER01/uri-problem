n = float(input())
for i in range(100):
    print('N[{}] = {:.4f}'.format(i, n))
    n /= 2
