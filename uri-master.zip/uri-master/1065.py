q = 0
for i in range(5):
    if float(input()) % 2 == 0: q += 1
print(q, 'valores pares')
