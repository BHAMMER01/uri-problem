for i in range(1, int(input())+1):
    print(i, i**2, i**3)
    print(i, i**2+1, i**3+1)
