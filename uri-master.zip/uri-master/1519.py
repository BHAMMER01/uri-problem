while True:
    try:
        e = str(input()).split()
    except EOFError: break
    
