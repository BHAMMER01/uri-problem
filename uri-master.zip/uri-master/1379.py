while True:
    e = str(input()).split()
    a = int(e[0])
    b = int(e[1])
    if a == 0 == b: break
    print(2 * a - b)
