x = int(input())
y = float(input())
print('{:.3f} km/l'.format(x / y))
