from math import ceil, log2
for g in range(int(input())):
    print(ceil(log2(float(input()))), 'dias')
