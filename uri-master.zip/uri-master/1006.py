a = float(input())
b = float(input())
c = float(input())
m = (a * 2 + b * 3 + c * 5) / 10
print('MEDIA = {:.1f}'.format(m))
