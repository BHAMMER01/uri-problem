#include <iostream>
#include <cmath>

using namespace std;

int main(void) {
   int a, b, c;
   while (cin >> a >> b >> c and (a or b or c))
      cout << int(cbrt(a*b*c)) << endl;
   return 0;
}

