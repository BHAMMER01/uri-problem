q = int(input())
for p in range(q):
    r = int(input())
    for s in range(r):
        n = int(input())
        if n == 1: print('Rolien')
        elif n == 2: print('Naej')
        elif n == 3: print('Elehcim')
        else: print('Odranoel')
