p = 0
for i in range(6):
    if float(input()) > 0: p += 1
print(p, 'valores positivos')
