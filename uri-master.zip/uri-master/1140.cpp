#include <iostream>

using namespace std;

int main(void) {
    char
    while (c = getchar() && c == '\0')
    return 0;
}

